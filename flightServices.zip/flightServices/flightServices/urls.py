from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from flightApp import views

router = DefaultRouter()
router.register('flights', views.FlightViewset)
router.register('passengers', views.PassengerViewset)
router.register('reservations', views.ReservationViewset)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(router.urls)),
    path('flightServices/findFlights/', views.find_flights),
    path('flightServices/saveReservation/', views.save_reservation)
    # There will be no default UI created for this by django-
    # - so test this using POSTMAN and instead of selecting BOdy use, xxx-form-urlencoded because that's how data-
    # - is sent.
]
