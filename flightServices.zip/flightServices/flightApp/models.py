from django.db import models



class Flight(models.Model):
    flightNumber = models.CharField(max_length=10)
    operatingAirlines = models.CharField(max_length=20)
    departureCity = models.CharField(max_length=20)
    arrivalCity = models.CharField(max_length=20)
    dateOfDeparture = models.DateField()
    estimatedTimeOfDeparture = models.TimeField()

class Passenger(models.Model):
    firstName = models.CharField(max_length=20)
    lastName = models.CharField(max_length=20)
    middleName = models.CharField(max_length=20)
    email = models.CharField(max_length=20)
    phone = models.CharField(max_length=20)

class Reservation(models.Model):
    flight = models.ForeignKey(Flight, on_delete=models.CASCADE) # Here we have kept one to one relationship -
    # - between flight and reservation, but as their are multiple passengers and multiple passengers can have-
    # - multiple reservations thus we need many to many relationship (or simply a foreign key)-
    # - instead of one to one. Also this table -
    # - will store flight_id and the respective passenger_id who is travelling through that flight.
    passenger = models.OneToOneField(Passenger, on_delete=models.CASCADE)
