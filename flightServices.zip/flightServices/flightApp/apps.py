from django.apps import AppConfig


class FlightappConfig(AppConfig):
    name = 'flightApp'
